
#include <function2/function2.hpp>

int main() {
  fu2::function<void()> myfn = [] {
    //
  };
  myfn();
  return 0;
}
