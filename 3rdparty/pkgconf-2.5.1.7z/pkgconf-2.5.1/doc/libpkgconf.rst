libpkgconf - an API for managing `pkg-config` modules
=====================================================

.. toctree::
   :maxdepth: 2

   libpkgconf-argvsplit
   libpkgconf-audit
   libpkgconf-cache
   libpkgconf-client
   libpkgconf-dependency
   libpkgconf-fragment
   libpkgconf-path
   libpkgconf-personality
   libpkgconf-pkg
   libpkgconf-queue
   libpkgconf-tuple
