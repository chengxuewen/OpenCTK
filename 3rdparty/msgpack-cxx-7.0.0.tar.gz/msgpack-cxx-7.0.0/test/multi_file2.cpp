#include <msgpack.hpp>

int main() {}
