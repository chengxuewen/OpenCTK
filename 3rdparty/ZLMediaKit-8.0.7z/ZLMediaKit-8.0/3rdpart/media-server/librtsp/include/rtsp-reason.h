#ifndef _rtsp_reason_h_
#define _rtsp_reason_h_

const char* rtsp_reason_phrase(int code);

#endif /* !_rtsp_reason_h_ */
