#ifndef _dash_proto_h_
#define _dash_proto_h_

enum
{
	DASH_STATIC = 0,
	DASH_DYNAMIC,
};

#endif /* !_dash_proto_h_ */
